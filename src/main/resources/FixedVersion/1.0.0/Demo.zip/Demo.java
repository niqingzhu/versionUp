package de.idos.updates;

import java.io.PrintStream;

public class Demo
{
  public void startDemo()
  {
    System.out.println("v1.0.0 started successfully.");
  }
}